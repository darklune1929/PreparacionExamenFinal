package pe.edu.pucp.gamesoft.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBManager {
    /*Coloque sus datos de conexión*/
    private Connection con;
    private String url = "jdbc:mysql://examenfinal.cadqr3wt6ain.us-east-1.rds.amazonaws.com:3306/laboratorio14?useSSL=false";
    private String user = "admin";
    private String password = "examenfinal";
    private static DBManager dbManager;
    
    public static DBManager getInstance(){
        if(dbManager == null){
            createInstance();
        }
        return dbManager;
    }
    
    public Connection getConnection(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.
                getConnection(url,user,password);
        }catch(ClassNotFoundException | SQLException ex){
            System.out.println(ex.getMessage());
        }
        return con;
    }
    
    private static void createInstance(){
        if(dbManager == null){
            dbManager = new DBManager();    
        }
    }
}