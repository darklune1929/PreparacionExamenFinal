package pe.edu.pucp.gamesoft.model;

import java.io.Serializable;

public enum Clasificacion implements Serializable{
    EVERYONE, TEEN, MATURE, ADULTSONLY
}
