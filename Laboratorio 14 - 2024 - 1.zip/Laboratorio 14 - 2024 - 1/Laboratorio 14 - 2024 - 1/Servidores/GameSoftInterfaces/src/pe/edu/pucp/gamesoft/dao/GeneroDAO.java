package pe.edu.pucp.gamesoft.dao;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import pe.edu.pucp.gamesoft.model.Genero;

public interface GeneroDAO extends Remote{
    ArrayList<Genero> listarTodos() throws RemoteException;
}
