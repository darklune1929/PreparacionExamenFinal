﻿using GameSoftWA.Referencias;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GameSoftWA
{
    /* Colocar sus datos personales
     * ------------------------------------------------
     * Nombre Completo:
     * Codigo PUCP:
     * ------------------------------------------------
     */

    public partial class RegistrarVideojuego : System.Web.UI.Page
    {
        private Referencias.GeneroWSClient daoGenero;
        private Referencias.VideojuegoWSClient daoVideojuego;
        private Referencias.videojuego videojuego;
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!IsPostBack)
            {
                daoGenero = new Referencias.GeneroWSClient();
                ddlGenero.DataSource = new BindingList<Referencias.genero>(daoGenero.listarGenerosTodos().ToList());
                ddlGenero.DataTextField = "nombre";
                ddlGenero.DataValueField = "idGenero";
                ddlGenero.DataBind();
            }
            String accion = Request.QueryString["accion"];
            String idVideojuego = Request.QueryString["idVideojuego"];
            if (accion != null && accion == "ver" && idVideojuego != null)
            {
                daoVideojuego = new Referencias.VideojuegoWSClient();
                lblTitulo.Text = "Visualizar Videojuego";
                videojuego = daoVideojuego.obtenerVideojuegoXId(Int32.Parse(idVideojuego));
                txtIdVideojuego.Text = videojuego.idVideojuego.ToString();
                txtNombre.Text = videojuego.nombre;
                ddlGenero.SelectedValue = videojuego.genero.idGenero.ToString();
                dtpFechaLanzamiento.Value = videojuego.fechaLanzamiento.ToString("yyyy-MM-dd");
                txtCostoDesarrollo.Text = videojuego.costoDesarrollo.ToString("N2");
                if (videojuego.clasificacion == Referencias.clasificacion.EVERYONE) rbEveryone.Checked = true;
                else if (videojuego.clasificacion == Referencias.clasificacion.TEEN) rbTeen.Checked = true;
                else if (videojuego.clasificacion == Referencias.clasificacion.MATURE) rbMature.Checked = true;
                else if (videojuego.clasificacion == Referencias.clasificacion.ADULTSONLY) rbAdultsOnly.Checked = true;
                if (videojuego.foto != null)
                {
                    string base64String = Convert.ToBase64String(videojuego.foto);
                    string imageUrl = "data:image/jpeg;base64," + base64String;
                    imgFotoVideojuego.ImageUrl = imageUrl;
                }
                
                deshabilitarCampos();
            }
            else
                lblTitulo.Text = "Registrar Videojuego";
            if (IsPostBack && fileUploadFotoVideojuego.PostedFile != null && fileUploadFotoVideojuego.HasFile)
            {
                string extension = System.IO.Path.GetExtension(fileUploadFotoVideojuego.FileName);
                if (extension.ToLower() == ".jpg" || extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".gif")
                {
                    string filename = Guid.NewGuid().ToString() + extension;
                    string filePath = Server.MapPath("~/Uploads/") + filename;
                    fileUploadFotoVideojuego.SaveAs(Server.MapPath("~/Uploads/") + filename);
                    imgFotoVideojuego.ImageUrl = "~/Uploads/" + filename;
                    imgFotoVideojuego.Visible = true;
                    FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);
                    Session["foto"] = br.ReadBytes((int)fs.Length);
                    fs.Close();
                }
                else
                {
                    Response.Write("Por favor, selecciona un archivo de imagen válido.");
                }
            }
        }

        protected void btnRegresar_Click(object sender, EventArgs e)
        {
            Response.Redirect("ListarVideojuegos.aspx");
        }

        public void deshabilitarCampos()
        {
            txtNombre.Enabled = false;
            ddlGenero.Enabled = false;
            dtpFechaLanzamiento.Disabled = true;
            txtCostoDesarrollo.Enabled = false;
            fileUploadFotoVideojuego.Enabled = false;
            rbEveryone.Disabled = true;
            rbTeen.Disabled = true;
            rbMature.Disabled = true;
            rbAdultsOnly.Disabled = true;
            btnGuardar.Visible = false;
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            videojuego = new Referencias.videojuego();
            videojuego.fechaLanzamientoSpecified = true;
            videojuego.clasificacionSpecified = true;
            videojuego.foto = (Byte[])Session["foto"];
            videojuego.genero = new Referencias.genero();
            videojuego.genero.idGenero = Int32.Parse(ddlGenero.SelectedValue);
            if (rbEveryone.Checked)
            {
                videojuego.clasificacion = clasificacion.EVERYONE;
            }
            else if (rbAdultsOnly.Checked)
            {
                videojuego.clasificacion = clasificacion.ADULTSONLY;
            }
            else if (rbTeen.Checked)
            {
                videojuego.clasificacion = clasificacion.TEEN;
            }
            else if (rbMature.Checked) videojuego.clasificacion = clasificacion.MATURE;
            videojuego.fechaLanzamiento = DateTime.Parse(dtpFechaLanzamiento.Value);
            videojuego.costoDesarrollo = Double.Parse(txtCostoDesarrollo.Text);
            videojuego.nombre = txtNombre.Text;
            daoVideojuego = new Referencias.VideojuegoWSClient();
            daoVideojuego.insertarVideojuego(videojuego);
            Response.Redirect("ListarVideojuegos.aspx");
        }
    }
}